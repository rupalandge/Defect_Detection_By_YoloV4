# defect > 2022-04-23 8:25pm
https://universe.roboflow.com/object-detection/defect-4hbgv

Provided by Roboflow
License: CC BY 4.0

